import React from "react";
import "./index.css";

const Footer = () => (
  <footer className="footer">
    <p>Some footer!</p>
  </footer>
);

export default Footer;