import React from "react";
import Loginform from "./Loginform";

const Login = () => {

    return (
        <div>
            <Loginform />
        </div>
    );
};

export default Login;