import React from "react";
import "./App.css";
import Webpage from "./Webpage";

const Call = () => {
  return (
  <div>
    <Webpage />
  </div>
  );
};

export default Call;